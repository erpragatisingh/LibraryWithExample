/** Automatically generated file. DO NOT MODIFY */
package in.wptrafficanalyzer.listviewwithsdcardimages;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}